<?php
$id_telegram = "7037081441";
$id_botTele  = "6922188252:AAGZ9xpglb_MA4qZ_tHZWWEErVp6O2n5z0Y";
?>
